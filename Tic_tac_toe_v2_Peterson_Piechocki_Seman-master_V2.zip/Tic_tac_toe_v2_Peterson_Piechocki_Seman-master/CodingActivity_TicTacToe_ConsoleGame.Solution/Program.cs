﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodingActivity_TicTacToe_ConsoleGame;

namespace CodingActivity_TicTacToe_ConsoleGame
{
    class Program
    {

        static void Main(string[] args)
        {
            
            GameController gameController = new GameController();
           
        }
    }
}
